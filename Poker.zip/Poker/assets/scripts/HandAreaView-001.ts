import { _decorator, Component, Node, Vec3 } from 'cc';
import { Card } from './Card';
const { ccclass } = _decorator;

@ccclass('HandArea')
export class HandArea extends Component {

    /** ��ǰ������ */
    topCard: Card | null = null;

    /** �����Ƶ�λ�� */
    getTopWorldPos(): Vec3 {
        return this.topCard
            ? this.topCard.node.worldPosition.clone()
            : this.node.worldPosition.clone();
    }

    replaceTop(card: Card) {
        this.topCard = card;
        card.node.setParent(this.node);
        card.node.setWorldPosition(this.getTopWorldPos());
    }
}
