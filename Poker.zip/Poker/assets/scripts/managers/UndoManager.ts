import { tween, Node } from 'cc';
import { UndoModel } from '../models/UndoModel.ts';
import { HandAreaView } from '../views/HandAreaView.ts';
import { CardView } from '../views/CardView.ts';

// Undo����
export class UndoManager {

    private stack: UndoModel[] = [];
    private moving = false;

    constructor(
        private handAreaView: HandAreaView,
        private tableArea: Node
    ) {}

    get isMoving(): boolean {
        return this.moving;
    }

    push(record: UndoModel) {
        this.stack.push(record);
    }

    undo(onBackToTable: (card: CardView) => void) {
        if (this.moving || this.stack.length === 0) return;

        const record = this.stack.pop()!;
        this.moving = true;

        const cardView = record.cardModel['view'] as CardView;
        const backToTable = record.fromParent === this.tableArea;

        cardView.node.setParent(record.fromParent);
        cardView.node.setSiblingIndex(record.prevSiblingIndex);

        tween(cardView.node)
            .to(0.3, { worldPosition: record.fromWorldPos })
            .call(() => {
                if (record.prevTopCard) {
                    this.handAreaView.topCardView =
                        record.prevTopCard['view'] as CardView;
                }

                if (backToTable) {
                    onBackToTable(cardView);
                } else {
                    cardView.node.zIndex = 0;
                }

                this.moving = false;
            })
            .start();
    }
}
