import { _decorator, Component, Node } from 'cc';
import { CardView } from '../views/CardView.ts';

const { ccclass, property } = _decorator;

@ccclass('HandAreaView')
export class HandAreaView extends Component {
    topCard: CardView | null = null; 

    getAllCards(): CardView[] {
        return this.node.children
            .map(n => n.getComponent(CardView))
            .filter(Boolean) as CardView[];
    }
}
