import { _decorator, Component, Node,CCInteger } from 'cc';
import { CardModel } from '../models/CardModel.ts';

const { ccclass, property } = _decorator;

@ccclass('CardView')
export class CardView extends Component {
    @property({ type:CCInteger })
    point: number = 0; 
}



