// Card.ts
import { _decorator, Component } from 'cc';
const { ccclass, property } = _decorator;

export enum Suit {
    Heart,
    Spade,
    Club,
    Diamond
}

@ccclass('Card')
export class Card extends Component {

    /** ��ɫ */
    @property
    suit: Suit = Suit.Heart;

    /** ������A=1, J=11, Q=12, K=13 */
    @property
    point: number = 1;
}
