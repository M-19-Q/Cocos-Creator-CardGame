import { _decorator, Component, Node, tween, Vec3 } from 'cc';
import { HandAreaView } from '../views/HandAreaView';
import { CardView } from '../views/CardView'; 

const { ccclass, property } = _decorator;

interface ActionRecord {
    card: CardView; 
    fromWorldPos: Vec3;
    fromParent: Node;
    prevTop: CardView | null; 
    prevSiblingIndex: number;
}

@ccclass('GameController')
export class GameController extends Component {
    @property(HandAreaView)
    handArea: HandAreaView = null!;

    @property(Node)
    tableArea: Node = null!;

    @property(Node)
    undoBtn: Node = null!;

    private actionStack: ActionRecord[] = [];
    private isMoving = false;

    start() {
        this.initTopCard();
        this.bindHandCards(); 
        this.bindTableCards();
        this.bindUndoButton();
    }

    // ��ʼ��
    private initTopCard() {
        const cards = this.getValidCardsInHandArea();
        if (cards.length === 0) {
            console.error('HandArea ��û�� CardView ���');
            this.handArea.topCard = null;
            return;
        }

        this.handArea.topCard = cards[0];
        this.setCardAsTopInHandArea(cards[0]);
    }

    // �¼���
    private bindHandCards() {
        this.handArea.node.children.forEach(node => {
            this.bindCardClickEvent(node, this.onClickHandCard.bind(this));
        });
    }

    private bindTableCards() {
        this.tableArea.children.forEach(node => {
            this.bindCardClickEvent(node, this.onClickTableCard.bind(this));
        });
    }

    private bindCardClickEvent(node: Node, callback: (card: CardView) => void) { 
        const card = node.getComponent(CardView); 
        if (!card) return;
        // ���Ƴ��ɵ��¼�����ֹ�ظ���
        node.off(Node.EventType.TOUCH_END, null, this);
        node.on(Node.EventType.TOUCH_END, () => {
            callback(card);
        }, this);
    }

    private bindUndoButton() {
        this.undoBtn.on(Node.EventType.TOUCH_END, () => {
            this.undo();
        }, this);
    }

    // ����߼�
    private onClickHandCard(card: CardView) { 
        if (this.isMoving) return;
        const top = this.handArea.topCard;
        if (!top) return;
        if (card === top) return;

        this.moveCardToTop(card);
    }

    private onClickTableCard(card: CardView) { 
        if (this.isMoving) return;
        const top = this.handArea.topCard;
        if (!top) return;

        // ֻ����������1�����Ի�ɫ��
        if (Math.abs(card.point - top.point) !== 1) {
            console.log(`Point mismatch: Table card ${card.point} vs Hand top card ${top.point}`);
            return;
        }

        this.moveCardToTop(card);
    }

    // �����ƶ��߼�
    private moveCardToTop(card: CardView) { 
        const prevTop = this.handArea.topCard!;
        const targetPos = prevTop.node.worldPosition.clone();
        
        const prevSiblingIndex = card.node.getSiblingIndex();
        const isFromTable = card.node.parent === this.tableArea;

        this.isMoving = true;

        this.actionStack.push({
            card,
            fromWorldPos: card.node.worldPosition.clone(),
            fromParent: card.node.parent!,
            prevTop,
            prevSiblingIndex
        });

        tween(card.node)
            .to(0.3, { worldPosition: targetPos })
            .call(() => {
                // �ƶ���ɺ�ҵ�������
                if (card.node.parent !== this.handArea.node) {
                    card.node.setParent(this.handArea.node);
                }
                
                // ���°��¼�
                if (isFromTable) {
                    this.bindCardClickEvent(card.node, this.onClickHandCard.bind(this));
                }
                
                // �����Ӿ�����
                this.setCardAsTopInHandArea(card);
                
                // �����߼�������
                this.handArea.topCard = card;
               
                // ����
                this.isMoving = false;
            })
            .start();
    }

    // ���ö�����
    private setCardAsTopInHandArea(card: CardView) { 
        if (card.node.parent !== this.handArea.node) {
            return;
        }

        card.node.zIndex = 100;
        this.handArea.node.children.forEach(node => {
            const otherCard = node.getComponent(CardView); 
            if (otherCard && otherCard !== card) {
                node.zIndex = 0;
            }
        });

        card.node.setSiblingIndex(9999);
    }

    // undo����
    private undo() {
        if (this.isMoving || this.actionStack.length === 0) return;

        const record = this.actionStack.pop()!;
        this.isMoving = true;

        const isBackToTable = record.fromParent === this.tableArea;

        // �ָ����ڵ�
        record.card.node.setParent(record.fromParent);
        // �ָ��ֵܽڵ�����
        record.card.node.setSiblingIndex(record.prevSiblingIndex);

        // ��������
        tween(record.card.node)
            .to(0.3, { worldPosition: record.fromWorldPos })
            .call(() => {
                // �ָ�������
                if (record.prevTop) {
                    this.handArea.topCard = record.prevTop;
                    this.setCardAsTopInHandArea(record.prevTop);
                }
                
                // ���°��¼�
                if (isBackToTable) {
                    this.bindCardClickEvent(record.card.node, this.onClickTableCard.bind(this));
                } else {
                    record.card.node.zIndex = 0;
                }
                
                // ����
                this.isMoving = false;
            })
            .start();
    }

    private getValidCardsInHandArea(): CardView[] { // 
        return this.handArea.node.children
            .map(n => n.getComponent(CardView)) 
            .filter(Boolean) as CardView[]; 
    }
}