import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('GameModel')
export class GameModel extends Component {
    start() {

    }

    update(deltaTime: number) {
        
    }
}


