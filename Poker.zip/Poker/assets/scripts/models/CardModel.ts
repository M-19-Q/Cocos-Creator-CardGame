import { Vec3, Node } from 'cc';
import { CardModel } from './CardModel';

// ��������
export interface UndoModel {
    cardModel: CardModel;
    fromWorldPos: Vec3;
    fromParent: Node;
    prevTopCard: CardModel | null;
    prevSiblingIndex: number;
}
