'use strict';

/**
 * 需要编译的 ts 文件夹
 */
exports.js = function() {
    return ['./'];
}

/**
 * 需要编译的 less 文件夹
 */
exports.css = function() {
    return [];
}